<div class="mx-3">
    <button wire:click="toggleLike"  style="border: none; background: none;">
        <!--[if BLOCK]><![endif]--><?php if($hasLiked): ?>
            <i class="bi bi-hand-thumbs-up-fill" style="color: #0099ff; font-size: 20px;" ></i>
        <?php else: ?>
            <i class="bi bi-hand-thumbs-up"  style=" font-size: 20px;" ></i>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </button>
    <span><?php echo e($post->likedBy()->count()); ?></span>
</div><?php /**PATH C:\Users\jukot\Herd\beack-it\resources\views/livewire/like-button.blade.php ENDPATH**/ ?>