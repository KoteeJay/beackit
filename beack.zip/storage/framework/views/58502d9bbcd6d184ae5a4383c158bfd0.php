<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['post']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['post']); ?>
<?php foreach (array_filter((['post']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="main-card my-5">
    <div class="px-3 d-flex profile justify-content-start align-items-center">
        <img src="<?php echo e(asset('assets/img/profile-img.jpg')); ?>" alt="">
        <div class="mx-3 d-flex justify-content-between align-items-center w-100 mt-3">
            <div>
                <h5><?php echo e($post->user->name); ?> </h5>
            </div>

            <?php echo e($slot); ?>


        </div>
    </div>
    <div class="px-3 blog-post" id="post-<?php echo e($post->id); ?>">
        <span class="short-text" style="display: inline;">
            <?php echo e(Str::limit($post->body, 200)); ?>

        </span>
        <span class="full-text" style="display: none;">
            <?php echo e($post->body); ?>

        </span>
        <?php if(strlen($post->body) > 200): ?>
        <span class="read-more-btn" style="color: #61b2ff; cursor: pointer" data-post-id="<?php echo e($post->id); ?>">Read More</span>
        <?php endif; ?>
    </div>
    <img src="<?php echo e($post->image); ?>" class="card-img-top mt-3" alt="...">

    <div class="d-flex justify-content-between my-3">

        <!-- Other post content -->
        
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('like-button', ['post' => $post]);

$__html = app('livewire')->mount($__name, $__params, 'lw-641618451-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            
            <div class="mx-3" style="font-size: 20px">
                <a href="<?php echo e(route('posts.show', $post->slug)); ?>"><i class="bi bi-chat"></i></a>
            </div>
         
        
    </div>
</div>
   

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const buttons = document.querySelectorAll('.read-more-btn');

        buttons.forEach(span => {
            span.addEventListener('click', (e) => {
                // Log to the console
                console.log('Button clicked');

                const postId = e.target.dataset.postId;
                const postElement = document.querySelector(`#post-${postId}`);

                const shortText = postElement.querySelector('.short-text');
                const fullText = postElement.querySelector('.full-text');
                const button = postElement.querySelector('.read-more-btn');

                // Toggle visibility
                if (fullText.style.display === 'none') {
                    shortText.style.display = 'none';
                    fullText.style.display = 'inline';  // changed to block for better visibility
                    button.textContent = ''; // change button text
                } 
                
            });
        });
    });
    document.addEventListener('click', function (e) {
    if (e.target.matches('.like-btn') || e.target.matches('.unlike-btn')) {
        e.preventDefault();

        const form = e.target.closest('form');
        const url = form.action;

        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            },
        })
        .then(response => response.text())
        .then(() => {
            location.reload(); // Reload the page to update the like count
        })
        .catch(error => console.error('Error:', error));
    }
    });
    function showLoginPrompt() {
        if (confirm('You need to log in to like this post. Do you want to log in now?')) {
            window.location.href = '<?php echo e(route('login')); ?>?redirect_to=' + encodeURIComponent(window.location.href);
        }
    }
</script>
<?php /**PATH C:\Users\jukot\Herd\beack-it\resources\views/components/posts/post-card.blade.php ENDPATH**/ ?>