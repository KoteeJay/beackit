<div class="search-bar m-auto">
    <form class="search-form d-flex align-items-center" wire:submit.prevent="search">
        <?php echo csrf_field(); ?>
        <input wire:model.live.debounce.300ms="query" 
        type="text" name="query" 
        placeholder="Search" 
        title="Enter search keyword">
        <button   wire:model="query"  type="submit" title="Search"><i class="bi bi-search"></i></button>
    </form>

    <ul class="list-group mt-3">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item py-3">
                <a href="<?php echo e(route('search.show', $post->id)); ?>"><?php echo e(Str::limit($post->body, 50)); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div><?php /**PATH C:\Users\jukot\Herd\beack-it\resources\views/livewire/search-box.blade.php ENDPATH**/ ?>