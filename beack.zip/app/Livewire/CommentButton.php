<?php

namespace App\Livewire;

use Livewire\Component;

class CommentButton extends Component
{
    public function render()
    {
        return view('livewire.show-post');
    }
}
