<?php

namespace App\Livewire;

use Livewire\Component;

class Available extends Component
{
    public function render()
    {
        return view('livewire.available');
    }
}
