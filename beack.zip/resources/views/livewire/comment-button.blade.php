<div class="mx-3" style="font-size: 20px">
    <a href="{{ route('posts.show', $post->id) }}"><i class="bi bi-chat"></i></a>
</div>